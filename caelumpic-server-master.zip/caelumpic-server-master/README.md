# caelumpic-server
API Rest do Caelumpic

`npm install`  

`npm start`  

;)
